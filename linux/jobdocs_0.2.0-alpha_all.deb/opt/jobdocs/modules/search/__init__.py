"""Search module for JobDocs"""
