"""Reporting module for JobDocs"""
